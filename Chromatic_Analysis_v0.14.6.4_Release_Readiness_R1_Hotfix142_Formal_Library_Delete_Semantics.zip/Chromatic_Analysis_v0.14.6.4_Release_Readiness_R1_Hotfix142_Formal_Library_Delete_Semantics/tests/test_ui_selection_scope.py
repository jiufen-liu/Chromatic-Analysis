"""Run with PySide6 and pytest, e.g. QT_QPA_PLATFORM=offscreen pytest -q tests/test_ui_selection_scope.py."""
from types import SimpleNamespace

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QAbstractItemView, QApplication, QLabel, QListWidget, QTabBar

from qtx_app.main_window import ColorCardPlanWindow, MainWindow


def app():
    return QApplication.instance() or QApplication([])


def test_palette_select_all_with_persistent_selection_and_ctrl_toggle():
    app()
    main=SimpleNamespace(
        _all_library_samples=lambda: [],
        statusBar=lambda: SimpleNamespace(showMessage=lambda *args: None),
    )
    card={'card_id':'test','name':'79 色卡方案','layout':[{'sample_key':f'file|{i}'} for i in range(79)],
          'settings':{'grid_cols':10,'auto_grid':True}}
    plan = ColorCardPlanWindow(main,card)
    plan.show()
    QApplication.processEvents()
    QTest.keyClick(plan.grid, Qt.Key_A, Qt.ControlModifier)
    assert len(plan.grid.selectedItems()) == 79
    assert len(plan.grid.selectionModel().selectedIndexes()) == 79
    assert plan.grid.dragDropMode()==QAbstractItemView.DragDrop
    assert all(item.data(Qt.UserRole) for item in plan.grid.selectedItems())
    QTest.keyClick(plan.grid, Qt.Key_C, Qt.ControlModifier)
    assert len(plan._clipboard_keys)==79
    assert len(QApplication.clipboard().text().splitlines())==79
    item = plan.grid.item(0)
    pos = plan.grid.visualItemRect(item).center()
    QTest.mouseClick(plan.grid.viewport(), Qt.LeftButton, Qt.ControlModifier, pos=pos)
    assert len(plan.grid.selectedItems()) == 78
    assert len(plan.grid.selectionModel().selectedIndexes()) == 78
    plan.close()


def test_palette_shortcuts_target_only_the_focused_scheme():
    app()
    main=SimpleNamespace(_all_library_samples=lambda: [],
                         statusBar=lambda: SimpleNamespace(showMessage=lambda *args: None))
    one=ColorCardPlanWindow(main,{'card_id':'one','name':'方案一',
                                   'layout':[{'sample_key':'one|0'},{'sample_key':'one|1'}],
                                   'settings':{'grid_cols':2}})
    two=ColorCardPlanWindow(main,{'card_id':'two','name':'方案二',
                                   'layout':[{'sample_key':'two|0'}],
                                   'settings':{'grid_cols':2}})
    one.show(); QApplication.processEvents()
    QTest.keyClick(one.grid,Qt.Key_A,Qt.ControlModifier)
    assert len(one.grid.selectedItems())==2
    QTest.keyClick(one.grid,Qt.Key_C,Qt.ControlModifier)
    assert len(one._clipboard_keys)==2 and not two._clipboard_keys
    two.show(); QApplication.processEvents()
    QTest.keyClick(two.grid,Qt.Key_A,Qt.ControlModifier)
    assert len(two.grid.selectedItems())==1
    two.close(); one.close()


def test_switch_library_scope_removes_old_qtabbar_entries():
    app()
    tabs = QTabBar()
    tabs.addTab('正式客户')
    fake = SimpleNamespace(
        library_scope='正式色库', library_customer_tabs=tabs,
        library_group_title=QLabel(), library_group_hint=QLabel(),
        open_library_customers=['正式客户'], minimized_library_customers=[],
        active_library_customer='正式客户', file_list=QListWidget(),
        library_selected_keys={'formal|1'}, hidden_cards={'formal|2'},
        library_page=1, _tiles_keys=['formal|1'], tool_subwindows={},
    )
    def open_customer(name):
        fake.open_library_customers.append(name)
        fake.library_customer_tabs.addTab(name)
        fake.active_library_customer=name
    fake.open_library_customer=open_customer
    fake.refresh_library_customer_tree=lambda: None
    MainWindow._library_scope_changed(fake,'官方色库')
    assert fake.library_scope=='官方色库'
    assert tabs.count()==1 and tabs.tabText(0)=='全部客户'
    assert not fake.library_selected_keys and not fake.hidden_cards
    assert fake.active_library_customer=='全部客户'


def test_formal_and_official_sql_scopes_do_not_mix(tmp_path):
    from qtx_app.library_store import LibraryStore
    store=LibraryStore.__new__(LibraryStore)
    store.path=tmp_path/'library.sqlite3'
    with store.connect() as db:
        db.execute('CREATE TABLE saved_qtx(path TEXT,customer TEXT,position INTEGER,mirror_path TEXT)')
        db.execute('CREATE TABLE saved_samples(qtx_path TEXT,payload TEXT)')
        db.executemany('INSERT INTO saved_qtx VALUES(?,?,?,?)',[
            ('/tmp/a.qtx','客户A',0,''),('/tmp/p.qtx','官方色库/Pantone',1,''),
            ('/tmp/r.qtx','官方色库/RAL',2,''),
        ])
    formal=[row.customer for row,_ in store.library_contents(scope='正式色库')]
    official=[row.customer for row,_ in store.library_contents(scope='官方色库')]
    assert formal==['客户A']
    assert official==['官方色库/Pantone','官方色库/RAL']
